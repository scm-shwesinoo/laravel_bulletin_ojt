<?php

namespace App\Dao\Post;

use App\Contracts\Dao\Post\PostDaoInterface;
use App\Models\Post;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class PostDao implements PostDaoInterface
{
  public function getPostList()
  {
    $data = Post::latest()->paginate(5);
    return $data;
  }

  public function savePost(Request $request)
  {
    $post = new Post();
    $post->title = 'Desc1';
    $post->description = 'Title';
    $post->created_user_id = Auth::user()->id ?? 1;
    $post->updated_user_id = Auth::user()->id ?? 1;
    dd('--------------------');
    dd($post);
    // $post->save();
    return $post;
  }
}
