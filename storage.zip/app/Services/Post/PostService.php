<?php

namespace App\Services\Post;

use App\Contracts\Dao\Post\PostDaoInterface;
use App\Contracts\Services\Post\PostServiceInterface;
use Illuminate\Http\Request;

class PostService implements PostServiceInterface
{

  private $postDao;

  public function __construct(PostDaoInterface $postDao)
  {
    $this->postDao = $postDao;
  }

  public function getPostList()
  {
    return $this->postDao->getPostList();
  }

  public function savePost(Request $request)
  {
    return $this->postDao->savePost($request);
  }
}
