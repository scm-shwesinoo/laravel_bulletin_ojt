<?php

namespace App\Contracts\Dao\Post;

use Illuminate\Http\Request;

interface PostDaoInterface 
{
  /**
   * To get post list
   */
  public function getPostList();

  public function savePost(Request $request);
}