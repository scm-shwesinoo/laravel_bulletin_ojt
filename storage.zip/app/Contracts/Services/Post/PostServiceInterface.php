<?php

namespace App\Contracts\Services\Post;

use Illuminate\Http\Request;

/**
 * Interface for post service
 */
interface PostServiceInterface
{
  /**
   * To get post list
   */
  public function getPostList();

  public function savePost(Request $request);
}
