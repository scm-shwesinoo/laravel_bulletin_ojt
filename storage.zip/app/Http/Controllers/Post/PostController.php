<?php

namespace App\Http\Controllers\Post;

use App\Contracts\Services\Post\PostServiceInterface;
use App\Http\Controllers\Controller;
use App\Http\Requests\PostCreateRequest;
use App\Models\Post;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class PostController extends Controller
{
    private $postInterface;

    public function __construct(PostServiceInterface $postServiceInterface)
    {
        $this->postInterface = $postServiceInterface;
    }

    public function showPostList()
    {
        $postList = $this->postInterface->getPostList();
        return view('posts.list', compact('postList'));
    }

    public function showPostCreateView()
    {
        return view('posts.create');
    }

    public function submitPostCreateView(PostCreateRequest $request)
    {
        // $validator = validator($request->all());
        $validated = $request->validated();
        // dd($request['title'], $request['description']);
        // if ($validator->fails()) {
        //     return back()->withErrors($validator);
        // }
        return redirect()
            ->route('post.create.confirm')
            ->withInput();
    }

    // public function showPostCreateConfirmView()
    // {
    //     if (old()) {
    //         return view('posts.create-confirm');
    //     }
    //     return redirect()->route('postlist');
    // }

    // public function submitPostCreateConfirmView(Request $request)
    // {
    //     // $post = $this->postInterface->savePost($request);
    //     $post = new Post();
    //     $post->title = 'Desc1';
    //     $post->description = 'Title';
    //     $post->created_user_id = Auth::user()->id ?? 1;
    //     $post->updated_user_id = Auth::user()->id ?? 1;
    //     dd('--------------------');
    //     dd($post);
    //     return redirect()->route('postlist');
    // }

    public function showPostCreateConfirmView()
    {
        if (old()) {
            return view('posts.create-confirm');
        }
        return redirect()->route('postlist');
    }

    /**
     * To submit post create confirm view
     * @param Request $request
     * @return View post list
     */
    public function submitPostCreateConfirmView(Request $request)
    {
        $post = new Post();
        $post->title = $request['title'];
        $post->description = $request['description'];
        $post->created_user_id = Auth::user()->id ?? 1;
        $post->updated_user_id = Auth::user()->id ?? 1;
        dd('--------------------');
        dd($request['title']);
        $post = $this->postInterface->savePost($request);
        return redirect()->route('postlist');
    }
}
