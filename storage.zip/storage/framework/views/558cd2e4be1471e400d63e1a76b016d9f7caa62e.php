<?php $__env->startSection('content'); ?>
<div class="container pt-5">
  <div class="row">
    <div class="col-md-12">
      <div class="card">
        <div class="card-header">Post List</div>
        <div class="card-body">
          <div class="row mb-2 search-bar d-flex justify-content-end">
              <label class="px-0 py-2 w-auto search-lbl">Keyword :</label>
              <input class="search-input mb-2 mx-2 w-auto form-control" type="text" id="search-keyword" />
              <button class="btn btn-outline-primary mb-2 mx-2 w-auto search-btn" id="search-click">Search</button>
              <a class="btn btn-primary mb-2 mx-2 w-auto header-btn px-3" href="#"><?php echo e(__('Create')); ?></a>
              <a class="btn btn-primary mb-2 mx-2 w-auto header-btn px-3" href="#"><?php echo e(__('Upload')); ?></a>
              <a class="btn btn-primary mb-2 mx-2 w-auto px-3 header-btn" href="#"><?php echo e(__('Download')); ?></a>
          </div>
          <table class="table table-bordered table-hover rounded">
            <thead>
              <tr>
                <th class="header-cell" scope="col">Post Title</th>
                <th class="header-cell" scope="col">Post Description</th>
                <th class="header-cell" scope="col">Posted User</th>
                <th class="header-cell" scope="col">Posted Date</th>
                <th class="header-cell" scope="col">Operation</th>
              </tr>
            </thead>
            <tbody>
              <?php $__currentLoopData = $postList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td style="width: 20%;"><?php echo e($post->title); ?></td>
                <td style="width: 30%;"><?php echo e($post->description); ?></td>
                <td><?php echo e($post->created_user_id); ?></td>
                <td><?php echo e(date('Y/m/d', strtotime($post->created_at))); ?></td>
                <td>Edit</td>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
          <div class="d-flex justify-content-end">
            <?php echo $postList->links(); ?>

          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OJT\PHP_OJT\bulletin-board\resources\views/posts/list.blade.php ENDPATH**/ ?>