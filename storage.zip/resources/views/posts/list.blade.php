@extends('layouts.app')

@section('content')
<div class="container pt-5">
  <div class="row">
    <div class="col-md-12">
      <div class="card">
        <div class="card-header">Post List</div>
        <div class="card-body">
          <div class="row mb-2 search-bar d-flex justify-content-end">
            <label class="px-0 py-2 w-auto search-lbl">Keyword :</label>
            <input class="search-input mb-2 mx-2 w-auto form-control" type="text" id="search-keyword" />
            <button class="btn btn-outline-primary mb-2 mx-2 w-auto search-btn" id="search-click">Search</button>
            <a class="btn btn-primary mb-2 mx-2 w-auto header-btn px-3" href="{{ url('post/create') }}">{{ __('Create') }}</a>
            <a class="btn btn-primary mb-2 mx-2 w-auto header-btn px-3" href="#">{{ __('Upload') }}</a>
            <a class="btn btn-primary mb-2 mx-2 w-auto px-3 header-btn" href="#">{{ __('Download') }}</a>
          </div>
          <table class="table table-bordered table-hover">
            <thead>
              <tr>
                <th class="header-cell" scope="col">Post Title</th>
                <th class="header-cell" scope="col">Post Description</th>
                <th class="header-cell" scope="col">Posted User</th>
                <th class="header-cell" scope="col">Posted Date</th>
                <th class="header-cell" scope="col">Operation</th>
              </tr>
            </thead>
            <tbody>
              @foreach($postList as $post)
              <tr>
                <td style="width: 20%;"><a href="#" data-bs-toggle="modal" data-bs-target="#post-detail-modal">{{$post->title}}</a></td>
                <td style="width: 40%;">{{$post->description}}</td>
                <td style="width: 12%;">{{$post->created_user_id}}</td>
                <td style="width: 12%;">{{date('Y/m/d', strtotime($post->created_at))}}</td>
                <td style="width: 15%;">
                  <button type="button" class="btn btn-info text-light">Edit</button>
                  <button type="button" class="btn btn-danger">Delete</button>
                </td>
              </tr>
              @endforeach
            </tbody>
          </table>
          <div class="d-flex justify-content-end">
            {!! $postList->links() !!}
          </div>

          <div class="modal fade" id="post-detail-modal" tabindex="-1" aria-labelledby="postModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered">
              <div class="modal-content">
                <div class="modal-header">
                  <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
                  <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                  ...
                </div>
                <div class="modal-footer">
                  <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
@endsection