<?php

use App\Http\Controllers\HomeController;
use App\Http\Controllers\Post\PostController;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Auth::routes();

Route::get('/', function () {
  return redirect()->route('postlist');
});

Route::get('/post/list', [PostController::class, 'showPostList'])->name('postlist');

Route::get('/home', [HomeController::class, 'index'])->name('home');


Route::get('/post/create', [PostController::class, 'showPostCreateView'])->name('create.post');
Route::post('/post/create', [PostController::class, 'submitPostCreateView'])->name('create.post');
Route::get('/post/create/confirm', [PostController::class, 'showPostCreateConfirmView'])->name('post.create.confirm');
Route::post('/post/create/confirm', [PostController::class, 'submitPostCreateConfirmView'])->name('post.create.confirm');
